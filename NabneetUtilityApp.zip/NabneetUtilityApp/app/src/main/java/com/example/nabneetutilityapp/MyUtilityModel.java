package com.example.nabneetutilityapp;

public class MyUtilityModel {
    static String RATE_API_CORE = "https://api.exchangerate-api.com/v4/latest/AUD";
}
