package com.example.nabneetutilityapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {
    Handler handler;
    private final int DELAY_TIME = 1000;
    private ExchangeRateTask rateTask;
    String[] fromCurrencies = {"AUD"};
    String[] toCurrencies = {"AUD","USD","INR","CAD"};
    double[] rates = {-1.0,-1.0,-1.0,-1.0};
    private Boolean got_Data=false;

    class ExchangeRateTask extends AsyncTask<String,Void,Boolean>{
        @Override
        protected Boolean doInBackground(String... strings) {
            String rateApiUrl=MyUtilityModel.RATE_API_CORE + strings[0];
            String rateInfo=Helper.getInfo(rateApiUrl);
            if(rateInfo!=null){
                try {
                    JSONObject jsonObject = new JSONObject(rateInfo);
                    JSONObject rateObject = jsonObject.getJSONObject("rates");
                    for(int i=0; i<rates.length; i++){
                        rates[i]=rateObject.getDouble(toCurrencies[i]);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return true;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Boolean gotData) {
            //updating the screen
            if(gotData) {
                for (double rate : rates) {
                    Log.i("rates", String.valueOf(rate));
                }
                got_Data = gotData;
            }

            super.onPostExecute(gotData);
        }
    }
    public void convertClicked(View view){
        //test:convert AUD to INR
        if(got_Data){
            EditText fromAmount = findViewById(R.id.fromAmount);
            double fromAmountDouble = Double.parseDouble(fromAmount.getText().toString());
            double convertedAmount = fromAmountDouble * rates[2];
            TextView toAmount=findViewById(R.id.toAmount);
            toAmount.setText(Double.toString(convertedAmount));
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handler = new Handler();
        //display current time
        updateTime();
        rateTask = (ExchangeRateTask)new ExchangeRateTask().execute(fromCurrencies);
    }

    private void updateTime() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                String currentTime = Helper.getCurrentTime();
                TextView timeView = findViewById(R.id.timeView);
                timeView.setText(currentTime);
                handler.postDelayed(this,DELAY_TIME);
            }
        });

    }
}